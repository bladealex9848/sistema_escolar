  <footer>
    <div class="container">
      <div class="col-12 text-center mt-5">
        <p class="text-muted">Desarrollado con <i class="fas fa-heart text-danger"></i> por <a href="https://www.academy.joystick.com.mx">Joystick</a>.</p>
      </div>
    </div>
  </footer>

  <!-- inc_bee_footer.php -->
  <?php require_once INCLUDES.'inc_scripts.php'; ?>
</body>
</html>