<?php 

// Funciones directamente del proyecto en curso