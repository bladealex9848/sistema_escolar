<?php
 /**
  * Silence is golden
  */
?>