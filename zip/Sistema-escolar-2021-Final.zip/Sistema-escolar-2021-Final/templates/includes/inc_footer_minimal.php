  <?php require_once INCLUDES.'inc_scripts.php'; ?>
</body>
</html>